# Proyecto de facturación en Javascript

Desarrollo de proyecto de un sistema de facturación. Este proyecto fue desarrollado en clase. 